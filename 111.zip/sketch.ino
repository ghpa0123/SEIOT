int ledr = 8;
int ledy = 9;
int ledg = 10;

void setup() {
  // put your setup code here, to run once:
  Serial.begin(9600)
  pinMode(ledr, OUTPUT);
  pinMode(ledy, OUTPUT);
  pinMode(ledg, OUTPUT);
}

void loop(){
digitalWrite(ledr, HIGH);
digitalWrite();




}

void loop() {
  // put your main code here, to run repeatedly:

}
